<?php
declare(strict_types=1);

const MAX_REQUEST_BYTES = 1000000;
const MAX_BATCH_WRITES = 450;
const MAX_QUERY_DOCS = 5000;

function cfg(): array
{
    static $cached;
    if (is_array($cached ?? null)) return $cached;
    // The hosting account's private data directory is two levels above the
    // virtual host document root, regardless of whether this API is deployed
    // in the root site or a staging subdirectory such as /candidate/.
    $documentRoot = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), DIRECTORY_SEPARATOR);
    if ($documentRoot === '') throw new RuntimeException('Document root is unavailable');
    $dataDir = dirname(dirname($documentRoot));
    if (str_starts_with($dataDir, $documentRoot . DIRECTORY_SEPARATOR)) throw new RuntimeException('Private configuration path resolves inside the public web root');
    $privatePath = getenv('ELITESERVICE_CONFIG') ?: $dataDir . '/eliteservice-config.php';
    $runtimePath = getenv('ELITESERVICE_RUNTIME') ?: $dataDir . '/eliteservice-runtime.php';
    if (!is_file($privatePath) || !is_readable($privatePath) || !is_file($runtimePath) || !is_readable($runtimePath)) throw new RuntimeException('Private configuration missing');
    $private = require $privatePath;
    $runtime = require $runtimePath;
    if (!is_array($private) || !is_array($private['db'] ?? null) || !is_array($runtime)) throw new RuntimeException('Invalid private configuration');
    $d = $private['db'];
    $cached = $runtime + ['database' => [
        'host' => $d['host'] ?? '', 'port' => (int)($d['port'] ?? 3306), 'name' => $d['database'] ?? '',
        'user' => $d['username'] ?? '', 'password' => $d['password'] ?? '', 'charset' => $d['charset'] ?? 'utf8mb4',
    ]];
    return $cached;
}

function respond(int $status, array $payload, string $origin): never
{
    try { $allowed = cfg()['allowed_origins'] ?? []; } catch (Throwable) { $allowed = []; }
    if (is_array($allowed) && $origin !== '' && in_array($origin, $allowed, true)) {
        header('Access-Control-Allow-Origin: ' . $origin); header('Vary: Origin');
    }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('X-Frame-Options: DENY');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function db(): PDO
{
    $d = cfg()['database'] ?? [];
    foreach (['host', 'name', 'user', 'password'] as $key) if (!is_string($d[$key] ?? null) || $d[$key] === '') throw new RuntimeException('Database configuration incomplete');
    $charset = preg_match('/^[a-z0-9_]+$/i', (string)($d['charset'] ?? 'utf8mb4')) ? $d['charset'] : 'utf8mb4';
    $port = max(1, min(65535, (int)($d['port'] ?? 3306)));
    return new PDO("mysql:host={$d['host']};port={$port};dbname={$d['name']};charset={$charset}", $d['user'], $d['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
}

function decode64(string $value): string|false
{
    return base64_decode(strtr($value, '-_', '+/') . str_repeat('=', (4 - strlen($value) % 4) % 4), true);
}

function firebase_keys(): array
{
    $url = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
    $file = sys_get_temp_dir() . '/eliteservice-firebase-certs.json';
    if (is_file($file) && filemtime($file) > time() - 3600) {
        $cached = json_decode((string)file_get_contents($file), true);
        if (is_array($cached)) return $cached;
    }
    $ctx = stream_context_create(['http' => ['timeout' => 6, 'header' => "Accept: application/json\r\n"], 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
    $body = @file_get_contents($url, false, $ctx);
    $keys = is_string($body) ? json_decode($body, true) : null;
    if (!is_array($keys) || !$keys) throw new RuntimeException('Authentication verifier unavailable');
    @file_put_contents($file, json_encode($keys), LOCK_EX);
    return $keys;
}

function token_actor(PDO $pdo): array
{
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $auth = trim((string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? $headers['Authorization'] ?? $headers['authorization'] ?? ''));
    if (!preg_match('/^Bearer\s+([A-Za-z0-9._-]+)$/i', $auth, $m)) throw new DomainException('Authentication required');
    $parts = explode('.', $m[1]);
    if (count($parts) !== 3) throw new DomainException('Invalid authentication token');
    $header = json_decode((string)decode64($parts[0]), true); $claims = json_decode((string)decode64($parts[1]), true); $signature = decode64($parts[2]);
    if (!is_array($header) || !is_array($claims) || !is_string($signature) || ($header['alg'] ?? '') !== 'RS256' || !is_string($header['kid'] ?? null)) throw new DomainException('Invalid authentication token');
    $project = (string)(cfg()['firebase_project_id'] ?? ''); $now = time();
    if ($project === '' || ($claims['aud'] ?? '') !== $project || ($claims['iss'] ?? '') !== 'https://securetoken.google.com/' . $project ||
        !is_string($claims['sub'] ?? null) || $claims['sub'] === '' || strlen($claims['sub']) > 128 ||
        !is_numeric($claims['exp'] ?? null) || (int)$claims['exp'] <= $now || !is_numeric($claims['iat'] ?? null) || (int)$claims['iat'] > $now + 60) throw new DomainException('Expired or invalid authentication token');
    $cert = firebase_keys()[$header['kid']] ?? null;
    $x509 = is_string($cert) ? openssl_x509_read($cert) : false; $key = $x509 ? openssl_pkey_get_public($x509) : false;
    if (!$key || openssl_verify($parts[0] . '.' . $parts[1], $signature, $key, OPENSSL_ALGO_SHA256) !== 1) throw new DomainException('Invalid authentication token');
    $workspace = (string)(cfg()['workspace_id'] ?? '');
    $stmt = $pdo->prepare('SELECT data_json FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?');
    $stmt->execute([$workspace, 'workspaces/' . $workspace . '/members', $claims['sub']]); $raw = $stmt->fetchColumn();
    if (!is_string($raw)) throw new DomainException('Account is not enabled');
    $member = json_decode($raw, true);
    if (!is_array($member) || ($member['active'] ?? true) === false || !in_array($member['role'] ?? '', ['owner','dispatcher_logistic','logistic','master'], true)) throw new DomainException('Account is not enabled');
    return ['uid' => $claims['sub'], 'id' => (string)($member['id'] ?? $claims['sub']), 'role' => (string)$member['role'], 'name' => (string)($member['name'] ?? ''), 'master' => (string)($member['master'] ?? ''), 'shift' => (string)($member['shift'] ?? '')];
}

function path_parts(string $path): array
{
    $path = trim($path, '/');
    if ($path === '' || strlen($path) > 255 || preg_match('/[^A-Za-z0-9._\/-]/', $path)) throw new DomainException('Invalid document path');
    $parts = explode('/', $path);
    if (count($parts) < 4 || count($parts) % 2 !== 0 || $parts[0] !== 'workspaces' || $parts[1] !== (string)(cfg()['workspace_id'] ?? '')) throw new DomainException('Invalid workspace path');
    return $parts;
}

function coll_path(string $path): string { $p = path_parts($path); array_pop($p); return implode('/', $p); }
function doc_id(string $path): string { $p = path_parts($path); return (string)array_pop($p); }

function collection_allowed(string $collection, array $actor, string $action, ?string $id = null, ?array $data = null): bool
{
    $p = explode('/', $collection); $tail = array_slice($p, 2); $leaf = implode('/', $tail); $role = $actor['role'];
    if ($role === 'owner') return true;
    if ($role === 'master') {
        if ($action === 'read') return in_array($leaf, ['masterAssignments','masterPhones','config/public'], true);
        return in_array($leaf, ['masterAssignments','orders'], true);
    }
    $readable = ['orders','dispatcherOrders','orderCloseData','members','shiftClosures','shiftReports','masterAssignments','masterPhones','masterShifts','config/public','config/payroll','config/payrollPolicy'];
    if ($action === 'read') return in_array($leaf, $readable, true) && !($leaf === 'members' && ($data['role'] ?? '') === 'owner') && !($leaf === 'weeklyShiftReports');
    return in_array($leaf, ['orders','dispatcherOrders','orderCloseData','shiftClosures','shiftReports','masterAssignments','masterPhones','masterShifts','config/public'], true);
}

function nested_value(array $data, string $field): mixed
{
    $v = $data; foreach (explode('.', $field) as $key) { if (!is_array($v) || !array_key_exists($key, $v)) return null; $v = $v[$key]; } return $v;
}

function compare_constraint(mixed $actual, string $op, mixed $expected): bool
{
    $cmp = is_numeric($actual) && is_numeric($expected) ? ((float)$actual <=> (float)$expected) : (strcmp((string)$actual, (string)$expected) <=> 0);
    return match ($op) {
        '==' => $actual === $expected || (is_scalar($actual) && is_scalar($expected) && (string)$actual === (string)$expected),
        '!=' => !($actual === $expected || (is_scalar($actual) && is_scalar($expected) && (string)$actual === (string)$expected)),
        '<' => $cmp < 0, '<=' => $cmp <= 0, '>' => $cmp > 0, '>=' => $cmp >= 0,
        'in' => is_array($expected) && in_array($actual, $expected, true),
        'array-contains' => is_array($actual) && in_array($expected, $actual, true),
        default => false,
    };
}

function clean_timestamps(mixed $value): mixed
{
    if (!is_array($value)) return $value;
    if (($value['__eliteTimestamp'] ?? false) === true) return gmdate('Y-m-d\TH:i:s\Z', (int)($value['seconds'] ?? time()));
    foreach ($value as $k => $v) $value[$k] = clean_timestamps($v);
    return $value;
}

function merge_document(array $old, array $patch): array
{
    foreach ($patch as $key => $value) {
        if (is_array($value) && is_array($old[$key] ?? null) && !array_is_list($value) && !array_is_list($old[$key])) {
            $old[$key] = merge_document($old[$key], $value);
        } else {
            $old[$key] = $value;
        }
    }
    return $old;
}

function safe_order_lock(PDO $pdo, string $workspace, string $id, array $actor, array $newData): void
{
    if (!in_array($actor['role'], ['dispatcher_logistic','logistic'], true)) return;
    $pickup = !empty($newData['_isPickup']);
    foreach (['workspaces/' . $workspace . '/orders', 'workspaces/' . $workspace . '/dispatcherOrders'] as $collection) {
        $q = $pdo->prepare('SELECT data_json FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?'); $q->execute([$workspace, $collection, $id]); $row = $q->fetchColumn();
        if (is_string($row)) { $existing = json_decode($row, true); if (is_array($existing)) {
            $pickup = $pickup || !empty($existing['_isPickup']);
            if (!empty($existing['_reportLockId']) && !$pickup && $existing !== $newData) throw new DomainException('Order is frozen by a closed shift report');
        } }
    }
}

function check_write(PDO $pdo, string $workspace, array $actor, string $path, string $type, ?array $data): void
{
    $collection = coll_path($path); $id = doc_id($path); $parts = path_parts($path); $leaf = implode('/', array_slice($parts, 2));
    if ($type === 'delete' && $actor['role'] !== 'owner') throw new DomainException('Only owner may delete CRM data');
    if (!collection_allowed($collection, $actor, 'write', $id, $data)) throw new DomainException('Write is not allowed for this role');
        if ($actor['role'] === 'master') {
        if ($leaf === 'masterAssignments') {
            if (isset($data['masterUid']) && $data['masterUid'] !== $actor['uid']) throw new DomainException('Assignment belongs to another master');
            $allowed = ['_masterStage','_acceptedAt','_enrouteAt','_arrivedAt','_workAt','_doneAt','_updatedAt','_masterReportedTotal','_masterReportedParts','_masterReportedReview','_masterNote','_masterReportAt','_workCompletedAt','_reviewSubmittedAt','_closeReviewState'];
            if (array_diff(array_keys($data), $allowed)) throw new DomainException('Master may only update own workflow report');
        } elseif ($leaf === 'orders') {
            $assigned = $pdo->prepare('SELECT data_json FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?');
            $assigned->execute([$workspace, 'workspaces/' . $workspace . '/masterAssignments', $id]);
            $assignment = $assigned->fetchColumn();
            if (!is_string($assignment) || (json_decode($assignment, true)['masterUid'] ?? '') !== $actor['uid']) throw new DomainException('Assignment belongs to another master');
            $allowed = ['_masterStage','_acceptedAt','_enrouteAt','_arrivedAt','_workAt','_doneAt','_updatedAt','_masterReportedTotal','_masterReportedParts','_masterReportedReview','_masterNote','_masterReportAt','_workCompletedAt','_reviewSubmittedAt','_closeReviewState','_status','_requiresCloseApproval','closeDate'];
            if (array_diff(array_keys($data), $allowed)) throw new DomainException('Master may only update workflow report fields');
        } else throw new DomainException('Master write is not allowed');
    }
    if (in_array($actor['role'], ['dispatcher_logistic','logistic'], true)) {
        if ($leaf === 'orders' || $leaf === 'dispatcherOrders' || $leaf === 'orderCloseData') safe_order_lock($pdo, $workspace, $id, $actor, $data ?? []);
        if ($leaf === 'shiftReports') {
            $q = $pdo->prepare('SELECT 1 FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?'); $q->execute([$workspace, $collection, $id]);
            if ($q->fetchColumn()) throw new DomainException('Closed shift reports are immutable');
            if (($data['closedBy'] ?? '') !== $actor['id']) throw new DomainException('Shift report actor mismatch');
        }
        if ($leaf === 'shiftClosures' && (($data['closedBy'] ?? '') !== $actor['id'] || ($data['shift'] ?? '') !== $actor['shift'])) throw new DomainException('Shift closure actor mismatch');
        if ($leaf === 'shiftClosures') {
            $q=$pdo->prepare('SELECT 1 FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?');$q->execute([$workspace,$collection,$id]);
            if($q->fetchColumn())throw new DomainException('Closed shift reports are immutable');
        }
        if ($leaf === 'members' || str_starts_with($leaf, 'config/payroll')) throw new DomainException('Owner only');
    }
    if ($actor['role'] === 'master' && $leaf === 'masterAssignments') {
        $q = $pdo->prepare('SELECT data_json FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?'); $q->execute([$workspace, $collection, $id]); $row = $q->fetchColumn();
        if (!is_string($row) || (json_decode($row, true)['masterUid'] ?? '') !== $actor['uid']) throw new DomainException('Assignment belongs to another master');
    }
}

function execute_query(PDO $pdo, string $workspace, array $actor, string $path, array $constraints, ?int $since): array
{
    $path = trim($path, '/'); $parts = explode('/', $path);
    if (count($parts) < 3 || count($parts) % 2 !== 1 || $parts[0] !== 'workspaces' || $parts[1] !== $workspace) throw new DomainException('Invalid collection path');
    if (!collection_allowed($path, $actor, 'read')) throw new DomainException('Read is not allowed for this role');
    $counter = $pdo->prepare('SELECT revision FROM crm_collection_revisions WHERE workspace_id=? AND collection_path=?'); $counter->execute([$workspace, $path]); $version = (int)($counter->fetchColumn() ?: 0);
    if ($since !== null && $since === $version) return ['unchanged' => true, 'version' => $version, 'docs' => []];
    $q = $pdo->prepare('SELECT document_id,data_json FROM crm_documents WHERE workspace_id=? AND collection_path=? ORDER BY document_id LIMIT ' . MAX_QUERY_DOCS); $q->execute([$workspace, $path]);
    $docs = [];
    foreach ($q->fetchAll() as $row) {
        $data = json_decode($row['data_json'], true); if (!is_array($data)) continue;
        if ($actor['role'] === 'dispatcher_logistic' && $path === 'workspaces/' . $workspace . '/members' && ($data['role'] ?? '') === 'owner') continue;
        if (in_array($actor['role'], ['dispatcher_logistic','logistic'], true) && $path === 'workspaces/' . $workspace . '/shiftReports' && ($data['closedBy'] ?? '') !== $actor['id']) continue;
        if (in_array($actor['role'], ['dispatcher_logistic','logistic'], true) && $path === 'workspaces/' . $workspace . '/shiftClosures' && (($data['closedBy'] ?? '') !== $actor['id'] || ($data['shift'] ?? '') !== $actor['shift'])) continue;
        if ($actor['role'] === 'master' && $path === 'workspaces/' . $workspace . '/masterAssignments' && ($data['masterUid'] ?? '') !== $actor['uid']) continue;
        if ($actor['role'] === 'master' && $path === 'workspaces/' . $workspace . '/masterPhones') {
            if (($data['masterUid'] ?? '') !== $actor['uid']) continue;
            $unlock=$data['unlockAt']??null; $seconds=is_array($unlock)?(int)($unlock['seconds']??0):(is_string($unlock)?(int)(strtotime($unlock)?:0):0);
            if (empty($data['earlyAccess']) && $seconds>time()) continue;
        }
        $ok = true; foreach ($constraints as $f) if (($f['type'] ?? '') === 'where' && !compare_constraint(nested_value($data, (string)($f['field'] ?? '')), (string)($f['op'] ?? ''), $f['value'] ?? null)) { $ok = false; break; }
        if ($ok) $docs[] = ['id' => $row['document_id'], 'data' => $data];
    }
    foreach ($constraints as $f) if (($f['type'] ?? '') === 'orderBy') {
        $field = (string)$f['field']; $desc = ($f['direction'] ?? 'asc') === 'desc';
        usort($docs, static function ($a, $b) use ($field, $desc) { $x = nested_value($a['data'], $field); $y = nested_value($b['data'], $field); $c = is_numeric($x) && is_numeric($y) ? ((float)$x <=> (float)$y) : strcmp((string)$x, (string)$y); return $desc ? -$c : $c; });
    }
    $lim = MAX_QUERY_DOCS; foreach ($constraints as $f) if (($f['type'] ?? '') === 'limit') $lim = max(1, min(MAX_QUERY_DOCS, (int)$f['count']));
    return ['unchanged' => false, 'version' => $version, 'docs' => array_slice($docs, 0, $lim)];
}

function main(): never
{
    $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? '')); $allowed = cfg()['allowed_origins'] ?? [];
    if ($origin !== '' && (!is_array($allowed) || !in_array($origin, $allowed, true))) respond(403, ['ok'=>false,'error'=>'origin'], $origin);
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($method === 'OPTIONS') {
        if ($origin === '' || !in_array($origin, $allowed, true)) respond(403, ['ok'=>false,'error'=>'origin'], $origin);
        header('Access-Control-Allow-Origin: ' . $origin); header('Vary: Origin'); header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); header('Access-Control-Allow-Headers: Authorization, Content-Type'); header('Access-Control-Max-Age: 600'); http_response_code(204); exit;
    }
    if ($method === 'GET' && ($_GET['action'] ?? '') === 'health') {
        try { $pdo = db(); $pdo->query('SELECT 1'); respond(200, ['ok'=>true,'service'=>'EliteService CRM','database'=>'ready'], $origin); }
        catch (Throwable) { respond(503, ['ok'=>false,'service'=>'EliteService CRM','database'=>'unavailable'], $origin); }
    }
    if ($method !== 'POST') respond(405, ['ok'=>false,'error'=>'method'], $origin);
    $size = (int)($_SERVER['CONTENT_LENGTH'] ?? 0); if ($size > MAX_REQUEST_BYTES) respond(413, ['ok'=>false,'error'=>'too_large'], $origin);
    $raw = file_get_contents('php://input', false, null, 0, MAX_REQUEST_BYTES + 1); if (!is_string($raw) || strlen($raw) > MAX_REQUEST_BYTES) respond(413, ['ok'=>false,'error'=>'too_large'], $origin);
    $body = json_decode($raw, true); if (!is_array($body)) respond(400, ['ok'=>false,'error'=>'json'], $origin);
    $pdo = db(); $actor = token_actor($pdo); $workspace = (string)cfg()['workspace_id']; $op = (string)($body['op'] ?? '');
    if ($op === 'getDoc') {
        $path = (string)($body['path'] ?? ''); $parts = path_parts($path); $collection = coll_path($path); $id = doc_id($path);
        if (!collection_allowed($collection, $actor, 'read')) respond(403, ['ok'=>false,'error'=>'read_forbidden'], $origin);
        $q = $pdo->prepare('SELECT data_json FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?'); $q->execute([$workspace,$collection,$id]); $rawData=$q->fetchColumn(); $data=is_string($rawData)?json_decode($rawData,true):null;
        if ($actor['role']!=='owner' && $collection==='workspaces/'.$workspace.'/members' && ($data['role']??'')==='owner') respond(403,['ok'=>false,'error'=>'read_forbidden'],$origin);
        if (in_array($actor['role'],['dispatcher_logistic','logistic'],true) && $collection==='workspaces/'.$workspace.'/shiftReports' && ($data['closedBy']??'')!==$actor['id']) respond(403,['ok'=>false,'error'=>'read_forbidden'],$origin);
        if (in_array($actor['role'],['dispatcher_logistic','logistic'],true) && $collection==='workspaces/'.$workspace.'/shiftClosures' && (($data['closedBy']??'')!==$actor['id'] || ($data['shift']??'')!==$actor['shift'])) respond(403,['ok'=>false,'error'=>'read_forbidden'],$origin);
        if ($actor['role']==='master' && $collection==='workspaces/'.$workspace.'/masterAssignments' && ($data['masterUid']??'')!==$actor['uid']) respond(403,['ok'=>false,'error'=>'read_forbidden'],$origin);
        if ($actor['role']==='master' && $collection==='workspaces/'.$workspace.'/masterPhones') {
            if (($data['masterUid']??'')!==$actor['uid']) respond(403,['ok'=>false,'error'=>'read_forbidden'],$origin);
            $unlock=$data['unlockAt']??null; $seconds=is_array($unlock)?(int)($unlock['seconds']??0):(is_string($unlock)?(int)(strtotime($unlock)?:0):0);
            if (empty($data['earlyAccess']) && $seconds>time()) respond(403,['ok'=>false,'error'=>'phone_locked'],$origin);
        }
        respond(200,['ok'=>true,'exists'=>is_array($data),'id'=>$id,'data'=>is_array($data)?$data:null],$origin);
    }
    if ($op === 'query') {
        $result = execute_query($pdo,$workspace,$actor,(string)($body['path']??''),is_array($body['constraints']??null)?$body['constraints']:[],isset($body['since'])?(int)$body['since']:null);
        respond(200,['ok'=>true]+$result,$origin);
    }
    if ($op !== 'batch' || !is_array($body['writes'] ?? null) || count($body['writes']) < 1 || count($body['writes']) > MAX_BATCH_WRITES) respond(400,['ok'=>false,'error'=>'invalid_operation'],$origin);
    $pdo->beginTransaction(); $changed=[]; $revision=0;
    try {
        foreach ($body['writes'] as $write) {
            if (!is_array($write) || !in_array($write['type']??'', ['set','update','delete'], true) || !is_string($write['path']??null)) throw new DomainException('Invalid write');
            $type=$write['type']; $path=$write['path']; path_parts($path); $collection=coll_path($path); $id=doc_id($path); $data=is_array($write['data']??null)?clean_timestamps($write['data']):[];
            check_write($pdo,$workspace,$actor,$path,$type,$data);
            $select=$pdo->prepare('SELECT data_json,revision FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=? FOR UPDATE'); $select->execute([$workspace,$collection,$id]); $old=$select->fetch();
            if ($type==='delete') {
                $del=$pdo->prepare('DELETE FROM crm_documents WHERE workspace_id=? AND collection_path=? AND document_id=?'); $del->execute([$workspace,$collection,$id]);
            } else {
                if ($type==='update' && !$old) throw new DomainException('Document not found');
                if ($type==='set' && !empty($write['merge']) && $old) { $prior=json_decode($old['data_json'],true); $data=merge_document(is_array($prior)?$prior:[],$data); }
                if ($type==='update' && $old) { $prior=json_decode($old['data_json'],true); $data=array_replace(is_array($prior)?$prior:[],$data); }
                $json=json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR);
                $save=$pdo->prepare('INSERT INTO crm_documents(workspace_id,collection_path,document_id,data_json,revision) VALUES(?,?,?,?,1) ON DUPLICATE KEY UPDATE data_json=VALUES(data_json),revision=revision+1'); $save->execute([$workspace,$collection,$id,$json]);
            }
            $changed[$collection][$id]=true;
            $ev=$pdo->prepare('INSERT INTO crm_events(workspace_id,revision,actor_uid,actor_role,event_type,collection_path,document_id) VALUES(?,0,?,?,?,?,?)'); $ev->execute([$workspace,$actor['uid'],$actor['role'],$type,$collection,$id]);
        }
        foreach (array_keys($changed) as $collection) {
            $bump=$pdo->prepare('INSERT INTO crm_collection_revisions(workspace_id,collection_path,revision) VALUES(?,?,1) ON DUPLICATE KEY UPDATE revision=revision+1'); $bump->execute([$workspace,$collection]);
            $q=$pdo->prepare('SELECT revision FROM crm_collection_revisions WHERE workspace_id=? AND collection_path=?'); $q->execute([$workspace,$collection]); $revision=max($revision,(int)$q->fetchColumn());
        }
        $pdo->commit(); respond(200,['ok'=>true,'revision'=>$revision,'changedCollections'=>count($changed)],$origin);
    } catch (Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
}

try { main(); }
catch (DomainException $e) { respond(403,['ok'=>false,'error'=>$e->getMessage()],trim((string)($_SERVER['HTTP_ORIGIN']??''))); }
catch (Throwable $e) { $safe=in_array($e->getMessage(),['revision_conflict','Authentication verifier unavailable','Account is not enabled'],true)?$e->getMessage():'service_unavailable'; respond(503,['ok'=>false,'error'=>$safe],trim((string)($_SERVER['HTTP_ORIGIN']??''))); }
