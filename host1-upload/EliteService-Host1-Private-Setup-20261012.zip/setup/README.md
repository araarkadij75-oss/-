# EliteService REG.RU data backend

This separate CRM backend stores order and staff documents in MySQL. Firebase Auth remains the sign-in provider. Deploy `api/index.php` as `/crm-api/index.php`; never use or overwrite `/api/`, which belongs to a different service. This package does not call B2BHelp or Avito.

## Private server files

Keep private configuration outside the public website root, under `/var/www/u3680049/data/`:

- `eliteservice-config.php` contains the dedicated DB connection values.
- `eliteservice-runtime.php` contains workspace/project IDs, allowed app origins, and the owner Auth UID. Never add DB passwords, PINs, or API secrets to the repository or web root.

The API verifies Firebase ID tokens using Google's published signing certificates and authorizes requests from the matching `members/{uid}` record. Health check: `GET https://crm.remontpkspb.ru/crm-api/index.php?action=health`.

## Deployment sequence

1. Use the separate `u3680049_eliteservice_crm` database on Host-1. It is currently linked to the hosting account's existing DB user; switch to a dedicated least-privilege user before putting customer data into it. Do not reuse the database or user for the existing website service.
2. Apply `schema.sql` to that database. It creates document storage, collection revisions, and an append-only event log.
3. Deploy `api/index.php` to `/var/www/u3680049/data/www/crm.remontpkspb.ru/crm-api/index.php`; keep both private config files at `/var/www/u3680049/data/`, outside the `www` tree. The API resolves the private directory from the virtual host document root and verifies that it is not inside the public root.
4. Run `scripts/export-firestore-private.mjs` from the local repository to export all Firestore workspace collections. Then run `scripts/prepare-regru-firestore-import.mjs` to normalize and filter the export into `%LOCALAPPDATA%/EliteServiceMigration/eliteservice-firestore-import.json`. Its manifest and a PHP runtime config are also written privately. The normalized data file contains customer and payroll data; never put it in Git or a public web directory.
5. After creating a dedicated database user and configuring the credential privately, place the normalized file at `/var/www/u3680049/data/eliteservice-firestore-import.json` and the importer under `/var/www/u3680049/data/setup/`. Run the importer only through a verified private CLI/SSH execution method; do not expose it through a public URL or run it through a web shell. If the hosting plan provides no safe private execution method, leave import disabled until one is available. The import is transactional, checks the configured owner UID and both canonical dispatchers, and refuses a non-empty workspace. Do not run `import-snapshot.php` for this complete export.
6. Check the API health response, then test owner, dispatcher, and master role flows in separate sessions, including cross-session order updates and closed-shift locks. Only then publish the candidate UI and update staff links.

## Source preservation and filtering

The direct Firestore export contains 2,943 documents in 11 collections. The normalized import preserves 1,388 orders, their 1,388 dispatcher projections, order close data, assignments, private phone access windows, 10 master schedule days, all 27 existing shift reports, the existing shift closure, payroll settings, and active member profiles for the owner, Артём (`artem`), Сергей (`seregatop`), and two active non-test masters. Firebase Auth remains unchanged. Blank totals and the source values are preserved; historical reports and payments are not fabricated.

The export includes an Avito inbox collection and external-sync configuration. The normalizer deliberately excludes all 103 Avito inbox documents and the Google bridge configuration, strips external integration keys from operational config, and keeps only `config/public`, `config/payroll`, and `config/payrollPolicy`. No Avito or B2BHelp API is called by the migration package.

The older `import-snapshot.php` accepts the owner UI JSON backup only. It cannot import the complete shift history and must not be used for the full Firestore migration.

## Current rollout status

The full Firestore source export and filtered normalized dataset are ready in the user's private local migration directory. A new Host-1 virtual host `crm.remontpkspb.ru` (PHP 8.3) and empty database `u3680049_eliteservice_crm` now exist; the DNS zone already resolves the CRM and `www.crm` names to Host-1. A free Let's Encrypt certificate was issued and linked to the virtual host, with HTTPS redirect enabled. No API or CRM data has been uploaded or imported. The database still needs a dedicated user/secret, schema, private config, and Firebase Auth domain authorization before live sign-in or synchronization can be tested. Existing GitHub Pages links remain live; do not direct staff to the new host until role isolation and cross-session checks pass.
