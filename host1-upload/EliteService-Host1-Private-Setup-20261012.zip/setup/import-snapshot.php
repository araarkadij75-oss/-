<?php
declare(strict_types=1);

function required_config(string $kind): array
{
    // Package this CLI importer at /data/setup/import-snapshot.php so its
    // default config lookup resolves to the private /data directory.
    $base = dirname(__DIR__);
    $privatePath = getenv('ELITESERVICE_CONFIG') ?: $base . '/eliteservice-config.php';
    $runtimePath = getenv('ELITESERVICE_RUNTIME') ?: $base . '/eliteservice-runtime.php';
    foreach ([$privatePath, $runtimePath] as $p) if (!is_file($p) || !is_readable($p)) throw new RuntimeException('Private server configuration missing');
    $private = require $privatePath; $runtime = require $runtimePath;
    if (!is_array($private) || !is_array($private['db'] ?? null) || !is_array($runtime)) throw new RuntimeException('Private server configuration invalid');
    $d = $private['db'];
    return $runtime + ['database'=>[
        'host'=>$d['host']??'', 'port'=>(int)($d['port']??3306), 'name'=>$d['database']??'',
        'user'=>$d['username']??'', 'password'=>$d['password']??'', 'charset'=>$d['charset']??'utf8mb4',
    ]];
}

function norm_login(string $v): string { return mb_strtolower(str_replace('ё','е',trim($v)), 'UTF-8'); }
function id_part(string $v): string
{
    if ($v === '' || strlen($v) > 160 || preg_match('/[^A-Za-z0-9._-]/', $v)) throw new RuntimeException('Invalid document identifier in source snapshot');
    return $v;
}
function no_integrations(array $v): array
{
    foreach (array_keys($v) as $k) if (preg_match('/google|b2b|avito|token|secret|password|pinhash/i', (string)$k)) unset($v[$k]);
    return $v;
}
function upsert_member(PDO $pdo, string $ws, string $uid, array $profile): void
{
    if ($uid === '' || strlen($uid) > 128) throw new RuntimeException('Invalid member UID in source');
    $doc = no_integrations($profile); unset($doc['pinHash'], $doc['pin'], $doc['password']);
    $stmt=$pdo->prepare('INSERT INTO crm_documents(workspace_id,collection_path,document_id,data_json,revision) VALUES(?,?,?,?,1)');
    $stmt->execute([$ws,"workspaces/$ws/members",$uid,json_encode($doc,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
}
function put_doc(PDO $pdo, string $ws, string $collection, string $id, array $data): void
{
    $stmt=$pdo->prepare('INSERT INTO crm_documents(workspace_id,collection_path,document_id,data_json,revision) VALUES(?,?,?,?,1)');
    $stmt->execute([$ws,"workspaces/$ws/$collection",id_part($id),json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR)]);
}
function member_key(string $v): string { return preg_replace('/[^\p{L}\p{N}]+/u',' ',norm_login($v)) ?? ''; }
function source_date_parts(mixed $value): ?array
{
    if (is_numeric($value) && (float)$value > 1000 && (float)$value < 90000) {
        $d = new DateTimeImmutable('1899-12-30 00:00:00', new DateTimeZone('UTC'));
        $d = $d->modify('+' . (int)floor((float)$value) . ' days');
        return [(int)$d->format('Y'), (int)$d->format('m'), (int)$d->format('d')];
    }
    $s = trim((string)$value);
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) return [(int)$m[1], (int)$m[2], (int)$m[3]];
    if (preg_match('/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{2,4})$/', $s, $m)) {
        $year = (int)$m[3]; if ($year < 100) $year += 2000;
        return [$year, (int)$m[2], (int)$m[1]];
    }
    return null;
}
function source_phone_unlock(array $row, array $settings): ?int
{
    if (!empty($row['_showPhoneToMaster'])) return 0;
    $explicit = trim((string)($row['_phoneUnlockAt'] ?? ''));
    if ($explicit !== '') { $ts = strtotime($explicit); if ($ts !== false) return $ts; }
    $parts = source_date_parts($row['visitDate'] ?? null);
    if ($parts === null || !checkdate($parts[1], $parts[2], $parts[0])) return null;
    $raw = norm_login((string)($row['visitTime'] ?? ''));
    $visitIso = sprintf('%04d-%02d-%02d', ...$parts);
    $today = (new DateTimeImmutable('now', new DateTimeZone('Europe/Moscow')))->format('Y-m-d');
    if (str_contains($raw, 'ближай')) {
        if ($visitIso === $today) {
            $assigned = strtotime((string)($row['_assignedAt'] ?? ''));
            return $assigned !== false ? $assigned : time();
        }
        $raw = (string)($settings['phoneNearestFutureTime'] ?? '09:00');
    } elseif (str_contains($raw, 'вечер')) {
        $raw = (string)($settings['phoneEveningTime'] ?? '18:00');
    } elseif ($raw === '') {
        $raw = (string)($settings['phoneNoTime'] ?? '09:00');
    }
    if (!preg_match('/([01]?\d|2[0-3])[:.]([0-5]\d)/u', $raw, $timeParts)) {
        if (preg_match('/^([01]?\d|2[0-3])\s*[-–—]/u', $raw, $hour)) $timeParts = [$hour[0], $hour[1], '00'];
        else $timeParts = [null, '09', '00'];
    }
    // Source UI interprets visit times in Moscow (UTC+3).
    $utc = new DateTimeImmutable(sprintf('%04d-%02d-%02d %02d:%02d:00', $parts[0], $parts[1], $parts[2], (int)$timeParts[1], (int)$timeParts[2]), new DateTimeZone('Europe/Moscow'));
    return $utc->getTimestamp();
}

try {
    if (PHP_SAPI !== 'cli' || $argc !== 2) throw new RuntimeException('Usage: php import-snapshot.php /private/path/backup.json');
    $file=$argv[1]; if (!is_file($file)||!is_readable($file)||filesize($file)>20_000_000) throw new RuntimeException('Snapshot file unavailable or too large');
    $raw=file_get_contents($file); if(!is_string($raw))throw new RuntimeException('Cannot read source snapshot');
    $source=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
    if(!is_array($source)||!is_array($source['orders']??null)||!is_array($source['settings']??null)||!is_array($source['settings']['staff']??null)) throw new RuntimeException('Source snapshot is not the expected EliteService backup');
    $cfg=required_config('all'); $ws=(string)($cfg['workspace_id']??''); $ownerUid=(string)($cfg['owner_uid']??''); $db=$cfg['database']??[];
    if($ws===''||$ownerUid===''||$ownerUid==='FILL_FROM_FIREBASE_AUTH_UID')throw new RuntimeException('Workspace or owner UID is not configured privately');
    foreach(['host','name','user','password'] as $k)if(!is_string($db[$k]??null)||$db[$k]===''||$db[$k]==='REPLACE_OUTSIDE_WEBROOT')throw new RuntimeException('Private database configuration is incomplete');
    $charset=preg_match('/^[a-z0-9_]+$/i',(string)($db['charset']??'utf8mb4'))?($db['charset']??'utf8mb4'):'utf8mb4';$port=max(1,min(65535,(int)($db['port']??3306)));
    $pdo=new PDO("mysql:host={$db['host']};port={$port};dbname={$db['name']};charset={$charset}",$db['user'],$db['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false]);
    foreach(['crm_documents','crm_collection_revisions','crm_events'] as $t)$pdo->query("SELECT 1 FROM $t LIMIT 0");
    $pdo->beginTransaction();
    $lock=$pdo->query("SELECT GET_LOCK('eliteservice-import',10)")->fetchColumn(); if((int)$lock!==1)throw new RuntimeException('Could not acquire migration lock');
    $check=$pdo->prepare('SELECT COUNT(*) FROM crm_documents WHERE workspace_id=?');$check->execute([$ws]);if((int)$check->fetchColumn()>0)throw new RuntimeException('Target database already contains CRM documents; refusing overwrite');

    // Keep only the two live dispatcher identities requested for the first rollout and active non-test masters.
    $staff=$source['settings']['staff'];$chosen=[];$masterByKey=[];
    foreach($staff as $p){if(!is_array($p)||($p['active']??true)===false)continue;$role=(string)($p['role']??'');$login=norm_login((string)($p['login']??''));
        $keepDispatcher=$role==='dispatcher_logistic'&&in_array($login,['artem','seregatop'],true);
        $keepMaster=$role==='master'&&!str_starts_with($login,'beta-')&&$login!=='';
        if(!$keepDispatcher&&!$keepMaster)continue;
        $uid=(string)($p['uid']??'');$name=(string)($p['name']??$login);if($uid==='')throw new RuntimeException('Selected account lacks Firebase UID');
        $profile=['id'=>(string)($p['id']??$uid),'uid'=>$uid,'login'=>$login,'loginLower'=>$login,'name'=>$name,'role'=>$role,'master'=>(string)($p['master']??''),'masterKey'=>member_key((string)($p['master']??'')),'shift'=>(string)($p['shift']??''),'active'=>true,'fixedMaster'=>($role==='master'&&($p['fixedMaster']??false)===true)];
        if(isset($chosen[$uid]))continue;$chosen[$uid]=$profile;if($role==='master')$masterByKey[$profile['masterKey']]=$uid;
    }
    $have=[];foreach($chosen as $p)$have[$p['login']]=true;
    foreach(['artem','seregatop'] as $required)if(empty($have[$required]))throw new RuntimeException('Required active dispatcher identity missing from source snapshot');
    upsert_member($pdo,$ws,$ownerUid,['id'=>'owner','uid'=>$ownerUid,'login'=>'owner','loginLower'=>'owner','name'=>'Владелец','role'=>'owner','active'=>true]);
    foreach($chosen as $uid=>$p)upsert_member($pdo,$ws,$uid,$p);

    $settings=$source['settings'];
    $orderSeen=[];$counts=['orders'=>0,'dispatcherOrders'=>0,'orderCloseData'=>0,'masterAssignments'=>0,'masterPhones'=>0];
    $dispatchFields=['orderId','direction','city','callDate','callTime','visitDate','visitTime','name','phone','address','request','master','dispatcher','review','closeDate','_status','_isPickup','_reportLockId','_showPhoneToMaster','_createdAt','_updatedAt','_createdBy','_createdByName','_createdByShift','_updatedBy','_updatedByName','_updatedByShift','_assignedAt','_assignedBy','_assignedByName','_workflow','_workflowCreatedAt','_requiresCloseApproval','_masterStage','_acceptedAt','_enrouteAt','_arrivedAt','_workAt','_doneAt','_workCompletedAt','_masterReportedTotal','_masterReportedParts','_masterReportedReview','_masterNote','_masterReportAt','_reviewSubmittedAt','_reviewReturnedAt','_reviewReturnedBy','_reviewReturnedByName','_closeReviewState','_closeReviewNote','_closeApprovedAt','_closeApprovedBy','_closeApprovedByName'];
    $closeFields=['orderId','parts','total','closeDate','_cashClosedAt','_cashClosedOn','_cashClosedBy','_cashClosedByName','_updatedAt','_updatedBy','_updatedByName','_updatedByShift'];
    foreach($source['orders'] as $row){if(!is_array($row))throw new RuntimeException('Malformed order row');$id=id_part(trim((string)($row['orderId']??'')));if(isset($orderSeen[$id]))throw new RuntimeException('Duplicate order ID in source snapshot');$orderSeen[$id]=true;
        unset($row['_cloudDocId']);put_doc($pdo,$ws,'orders',$id,$row);$counts['orders']++;
        $dispatch=array_intersect_key($row,array_flip($dispatchFields));put_doc($pdo,$ws,'dispatcherOrders',$id,$dispatch);$counts['dispatcherOrders']++;
        $close=array_intersect_key($row,array_flip($closeFields));put_doc($pdo,$ws,'orderCloseData',$id,$close);$counts['orderCloseData']++;
        $mKey=member_key((string)($row['master']??''));$masterUid=$masterByKey[$mKey]??'';
        if($masterUid!==''){
            $masterFields=['orderId','direction','city','callDate','callTime','visitDate','visitTime','name','address','request','master','dispatcher','review','closeDate','_status','_isPickup','_reportLockId','_showPhoneToMaster','_createdAt','_updatedAt','_assignedAt','_workflow','_workflowCreatedAt','_requiresCloseApproval','_masterStage','_acceptedAt','_enrouteAt','_arrivedAt','_workAt','_doneAt','_workCompletedAt','_masterReportedTotal','_masterReportedParts','_masterReportedReview','_masterNote','_masterReportAt','_reviewSubmittedAt','_closeReviewState'];
            $safe=array_intersect_key($row,array_flip($masterFields));$safe['masterUid']=$masterUid;$safe['masterKey']=$mKey;put_doc($pdo,$ws,'masterAssignments',$id,$safe);$counts['masterAssignments']++;
            if((string)($row['phone']??'')!==''){$seconds=source_phone_unlock($row,$settings);if($seconds!==null){put_doc($pdo,$ws,'masterPhones',$id,['orderId'=>$id,'phone'=>(string)$row['phone'],'masterUid'=>$masterUid,'unlockAt'=>['__eliteTimestamp'=>true,'seconds'=>$seconds],'earlyAccess'=>!empty($row['_showPhoneToMaster'])]);$counts['masterPhones']++;}}
        }
    }
    $public=[];foreach(['phoneEveningTime','phoneNoTime','phoneNearestFutureTime','masterRoster','disabledMasters','shift1Name','shift2Name'] as $k)if(array_key_exists($k,$settings))$public[$k]=$settings[$k];
    put_doc($pdo,$ws,'config','public',$public);
    $settingsCopy=no_integrations($settings);unset($settingsCopy['staff'],$settingsCopy['ownerPinHash'],$settingsCopy['accessEnabled']);put_doc($pdo,$ws,'config','operationalSettings',$settingsCopy);
    $payroll=[];foreach(['shiftBasePay','shiftCashThreshold','shiftCashRate','reviewBonus','fixedRate','threshold1','threshold2','gridLow','gridMid','gridHigh'] as $k)if(array_key_exists($k,$settings))$payroll[$k]=$settings[$k];put_doc($pdo,$ws,'config','payroll',$payroll);
    $policy=[];foreach(['shiftBasePay','shiftCashThreshold','shiftCashRate'] as $k)if(array_key_exists($k,$settings))$policy[$k]=$settings[$k];put_doc($pdo,$ws,'config','payrollPolicy',$policy);
    put_doc($pdo,$ws,'migration','source',['sourceSha256'=>hash('sha256',$raw),'exportedAt'=>(string)($source['exportedAt']??''),'importedAt'=>gmdate('c'),'ordersImported'=>$counts['orders'],'activeStaffImported'=>count($chosen)+1,'shiftReportsImported'=>0,'shiftClosuresImported'=>0,'note'=>'Shift reports and closures were absent from the source backup; no historical reports were fabricated.']);
    $revs=$pdo->prepare('INSERT INTO crm_collection_revisions(workspace_id,collection_path,revision) VALUES(?,?,1)');
    foreach(['members','orders','dispatcherOrders','orderCloseData','masterAssignments','masterPhones','config','migration'] as $col)$revs->execute([$ws,"workspaces/$ws/$col"]);
    $pdo->commit();$pdo->query("SELECT RELEASE_LOCK('eliteservice-import')");
    echo json_encode(['ok'=>true,'counts'=>$counts,'activeStaffImported'=>count($chosen)+1,'shiftReportsImported'=>0,'shiftClosuresImported'=>0,'sourceSha256'=>hash('sha256',$raw)],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL;
} catch(Throwable $e) {
    if(isset($pdo)&&$pdo instanceof PDO){if($pdo->inTransaction())$pdo->rollBack();try{$pdo->query("SELECT RELEASE_LOCK('eliteservice-import')");}catch(Throwable){}}
    fwrite(STDERR,'Import stopped safely: '.$e->getMessage().PHP_EOL);exit(1);
}
