<?php
declare(strict_types=1);

function private_config(): array
{
    // Package this CLI importer at /data/setup/import-firestore.php so its
    // default config lookup resolves to the private /data directory.
    $base = dirname(__DIR__);
    $privatePath = getenv('ELITESERVICE_CONFIG') ?: $base . '/eliteservice-config.php';
    $runtimePath = getenv('ELITESERVICE_RUNTIME') ?: $base . '/eliteservice-runtime.php';
    foreach ([$privatePath, $runtimePath] as $path) if (!is_file($path) || !is_readable($path)) throw new RuntimeException('Private server configuration missing');
    $private = require $privatePath; $runtime = require $runtimePath;
    if (!is_array($private) || !is_array($private['db'] ?? null) || !is_array($runtime)) throw new RuntimeException('Private server configuration invalid');
    $d = $private['db'];
    return $runtime + ['database' => ['host'=>$d['host']??'', 'port'=>(int)($d['port']??3306), 'name'=>$d['database']??'', 'user'=>$d['username']??'', 'password'=>$d['password']??'', 'charset'=>$d['charset']??'utf8mb4']];
}

function valid_id(string $id): string
{
    if ($id === '' || strlen($id) > 160 || preg_match('/[^A-Za-z0-9._-]/', $id)) throw new RuntimeException('Invalid source document identifier');
    return $id;
}

function validate_member(array $row): array
{
    if (!is_string($row['id'] ?? null) || !is_array($row['data'] ?? null)) throw new RuntimeException('Malformed member row');
    $uid = valid_id($row['id']); $data = $row['data'];
    if (($data['active'] ?? false) !== true || !in_array($data['role'] ?? '', ['owner','dispatcher_logistic','master'], true)) throw new RuntimeException('Inactive or unsupported member in import source');
    if (($data['role'] ?? '') === 'dispatcher_logistic') {
        $login = mb_strtolower(str_replace('ё','е',trim((string)($data['loginLower'] ?? $data['login'] ?? ''))), 'UTF-8');
        if (!in_array($login, ['artem','seregatop'], true)) throw new RuntimeException('Unexpected dispatcher in import source');
    }
    return [$uid, $data];
}

try {
    if (PHP_SAPI !== 'cli' || $argc !== 2) throw new RuntimeException('Usage: php import-firestore.php /private/path/eliteservice-firestore-import.json');
    $file = $argv[1];
    if (!is_file($file) || !is_readable($file) || filesize($file) > 20_000_000) throw new RuntimeException('Import snapshot unavailable or too large');
    $raw = file_get_contents($file); if (!is_string($raw)) throw new RuntimeException('Cannot read import snapshot');
    $source = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    $cfg = private_config(); $workspace = (string)($cfg['workspace_id'] ?? ''); $ownerUid = (string)($cfg['owner_uid'] ?? ''); $db = $cfg['database'] ?? [];
    if (($source['format'] ?? '') !== 'eliteservice-regru-import-v1' || ($source['complete'] ?? false) !== true || ($source['projectId'] ?? '') !== ($cfg['firebase_project_id'] ?? '') || ($source['workspaceId'] ?? '') !== $workspace || $workspace === '') throw new RuntimeException('Import identity or completeness check failed');
    if ($ownerUid === '' || $ownerUid === 'FILL_FROM_FIREBASE_AUTH_UID') throw new RuntimeException('Owner identity is not configured privately');
    foreach (['host','name','user','password'] as $key) if (!is_string($db[$key] ?? null) || $db[$key] === '' || $db[$key] === 'REPLACE_OUTSIDE_WEBROOT') throw new RuntimeException('Private database configuration incomplete');
    $charset = preg_match('/^[a-z0-9_]+$/i', (string)($db['charset'] ?? 'utf8mb4')) ? $db['charset'] : 'utf8mb4';
    $pdo = new PDO('mysql:host='.$db['host'].';port='.(int)($db['port']??3306).';dbname='.$db['name'].';charset='.$charset, $db['user'], $db['password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES=>false]);
    if ((int)$pdo->query("SELECT GET_LOCK('eliteservice-firestore-import', 5)")->fetchColumn() !== 1) throw new RuntimeException('Another import is running');
    $pdo->beginTransaction();
    $existing = $pdo->prepare('SELECT COUNT(*) FROM crm_documents WHERE workspace_id=?'); $existing->execute([$workspace]);
    if ((int)$existing->fetchColumn() !== 0) throw new RuntimeException('Target workspace is not empty; import refused');

    $allowed = ['config'=>['public','payroll','payrollPolicy'], 'dispatcherOrders'=>true, 'masterAssignments'=>true, 'masterPhones'=>true, 'masterShifts'=>true, 'members'=>true, 'orderCloseData'=>true, 'orders'=>true, 'shiftClosures'=>true, 'shiftReports'=>true];
    if (!is_array($source['rows'] ?? null) || !is_array($source['counts'] ?? null)) throw new RuntimeException('Import rows or manifest missing');
    $rows = []; $seen = []; $counts = []; $members = []; $activeMasterUids = []; $dispatcherLogins = [];
    foreach ($source['rows'] as $row) {
        if (!is_array($row)) throw new RuntimeException('Malformed import row');
        $collection = (string)($row['collection'] ?? ''); $id = valid_id((string)($row['id'] ?? '')); $data = $row['data'] ?? null;
        if (!isset($allowed[$collection]) || ($collection === 'config' && !in_array($id, $allowed['config'], true)) || !is_array($data)) throw new RuntimeException('Unexpected collection or malformed source document');
        $key = $collection.'/'.$id; if (isset($seen[$key])) throw new RuntimeException('Duplicate source document'); $seen[$key] = true;
        if ($collection === 'members') {
            [$uid, $data] = validate_member($row);
            if ($uid !== $id) throw new RuntimeException('Member UID/document ID mismatch');
            if ($data['role'] === 'owner' && $uid !== $ownerUid) throw new RuntimeException('Owner UID does not match private runtime config');
            if ($data['role'] === 'dispatcher_logistic') {
                $login = mb_strtolower(str_replace('ё','е',trim((string)($data['loginLower'] ?? $data['login'] ?? ''))), 'UTF-8');
                if (isset($dispatcherLogins[$login])) throw new RuntimeException('Duplicate dispatcher profile');
                $dispatcherLogins[$login] = true;
            }
            if ($data['role'] === 'master') $activeMasterUids[$uid] = true;
            $members[$uid] = $data;
        }
        $rows[] = [$collection,$id,$data]; $counts[$collection] = ($counts[$collection] ?? 0) + 1;
    }
    if (count($dispatcherLogins) !== 2 || empty($dispatcherLogins['artem']) || empty($dispatcherLogins['seregatop'])) throw new RuntimeException('Both canonical dispatcher profiles are required');
    if (!isset($members[$ownerUid]) || ($members[$ownerUid]['role'] ?? '') !== 'owner') throw new RuntimeException('Owner profile missing');
    if (($counts['orders'] ?? 0) !== ($counts['dispatcherOrders'] ?? -1)) throw new RuntimeException('Canonical and dispatcher order counts differ');
    foreach ($rows as [$collection,$id,$data]) {
        if (in_array($collection, ['masterAssignments','masterPhones'], true) && isset($data['masterUid']) && !isset($activeMasterUids[(string)$data['masterUid']])) throw new RuntimeException('Assignment references a master not imported');
    }
    if (($counts['shiftReports'] ?? 0) < 1 || !array_key_exists('shiftClosures', $counts)) throw new RuntimeException('Shift history is missing from import source');

    $insert = $pdo->prepare('INSERT INTO crm_documents(workspace_id,collection_path,document_id,data_json,revision) VALUES(?,?,?,?,1)');
    $collectionPaths = [];
    foreach ($rows as [$collection,$id,$data]) {
        $path = 'workspaces/'.$workspace.'/'.$collection;
        $insert->execute([$workspace,$path,$id,json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR)]);
        $collectionPaths[$path] = true;
    }
    $migration = ['sourceSha256'=>(string)($source['sourceSha256']??''),'sourceExportedAt'=>(string)($source['sourceExportedAt']??''),'importedAt'=>gmdate('c'),'counts'=>$counts,'excluded'=>$source['excluded']??[],'note'=>'Avito lead inbox and external integration configuration were intentionally excluded; source shift history was imported without synthesis.'];
    $insert->execute([$workspace,'workspaces/'.$workspace.'/migration','source',json_encode($migration,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
    $collectionPaths['workspaces/'.$workspace.'/migration'] = true;
    $revision = $pdo->prepare('INSERT INTO crm_collection_revisions(workspace_id,collection_path,revision) VALUES(?,?,1)');
    foreach (array_keys($collectionPaths) as $path) $revision->execute([$workspace,$path]);
    $pdo->commit(); $pdo->query("SELECT RELEASE_LOCK('eliteservice-firestore-import')");
    echo json_encode(['ok'=>true,'counts'=>$counts,'excluded'=>$source['excluded']??[],'sourceSha256'=>$source['sourceSha256']??''],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL;
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO) { if ($pdo->inTransaction()) $pdo->rollBack(); try { $pdo->query("SELECT RELEASE_LOCK('eliteservice-firestore-import')"); } catch (Throwable) {} }
    fwrite(STDERR,'Import stopped safely: '.$e->getMessage().PHP_EOL); exit(1);
}
