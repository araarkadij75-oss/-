<?php
declare(strict_types=1);

// Store as /var/www/u3680049/data/eliteservice-runtime.php (outside www).
return [
    'workspace_id' => 'master-ai-beta',
    'firebase_project_id' => 'master-ai-beta-9440599',
    'allowed_origins' => ['https://araarkadij75-oss.github.io', 'https://crm.remontpkspb.ru'],
    'owner_uid' => 'FILL_FROM_FIREBASE_AUTH_UID',
];
