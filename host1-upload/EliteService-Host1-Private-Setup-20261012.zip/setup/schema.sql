CREATE TABLE IF NOT EXISTS crm_documents (
  workspace_id VARCHAR(80) NOT NULL,
  collection_path VARCHAR(255) NOT NULL,
  document_id VARCHAR(160) NOT NULL,
  data_json MEDIUMTEXT NOT NULL,
  revision BIGINT UNSIGNED NOT NULL DEFAULT 1,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (workspace_id, collection_path, document_id),
  KEY idx_collection_updated (workspace_id, collection_path, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_collection_revisions (
  workspace_id VARCHAR(80) NOT NULL,
  collection_path VARCHAR(255) NOT NULL,
  revision BIGINT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (workspace_id, collection_path)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  workspace_id VARCHAR(80) NOT NULL,
  revision BIGINT UNSIGNED NOT NULL,
  actor_uid VARCHAR(128) NOT NULL,
  actor_role VARCHAR(32) NOT NULL,
  event_type VARCHAR(32) NOT NULL,
  collection_path VARCHAR(255) NOT NULL,
  document_id VARCHAR(160) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_workspace_revision (workspace_id, revision),
  KEY idx_collection_doc (workspace_id, collection_path, document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
